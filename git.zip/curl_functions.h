/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   curl_functions.h
 * Author: harry
 *
 * Created on April 9, 2018, 3:50 PM
 */

#ifndef CURL_FUNCTIONS_H
#define CURL_FUNCTIONS_H

#ifdef __cplusplus
extern "C" {
#endif




#ifdef __cplusplus
}
#endif

#endif /* CURL_FUNCTIONS_H */

